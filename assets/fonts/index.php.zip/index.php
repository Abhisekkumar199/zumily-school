
<script>window.location.href='https://www.zumilyschool.com';</script>  